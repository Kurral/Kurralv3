"""Tests for Kurral replay mechanism"""

